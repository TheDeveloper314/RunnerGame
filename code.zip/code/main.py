import pygame, sys
from random import choice, randint

# game settings
width = 800
height = 400
fps = 60

class Game():
	def __init__(self):
		# game set-up
		pygame.init()
		self.time = pygame.time.get_ticks()
		self.display_surface = pygame.display.set_mode((width, height))
		self.clock = pygame.time.Clock()
		pygame.display.set_caption("Runner")
		self.start_time = pygame.time.get_ticks()
		self.score = 0
		self.obstacle_spawn = pygame.USEREVENT + 1
		pygame.time.set_timer(self.obstacle_spawn, 900)
		self.game_active = False

		self._import_and_render()

		self.player = Player()
		self.obstacles = []

		# audio
		bgm = pygame.mixer.Sound("../audio/music.wav")
		bgm.set_volume(0.3)

		bgm.play(loops = -1)

	def run(self):
		while True:
			# event loop
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()

				if event.type == self.obstacle_spawn:
					self.obstacles.append(choice([Snail(), Snail(), Snail(), Fly()]))

				if not self.game_active and event.type == pygame.KEYDOWN:
					if event.key == pygame.K_SPACE:
						self.game_active = True
						self.start_time = pygame.time.get_ticks()

			# game logic
			# game active
			if self.game_active:
				self._get_score()
				self._blit_active()
				self._obstacle_animation()
				self.player.animation()
				self.player.jump()
				self._game_over()

			# game over
			else:
				self._blit_game_over()
				self.obstacles.clear()

			pygame.display.update()
			self.clock.tick(fps)

	def _import_and_render(self):
		self.sky_background = pygame.image.load("../graphics/sky.png").convert()
		self.ground_background = pygame.image.load("../graphics/ground.png").convert()
		self.font = pygame.font.Font("../font/Pixeltype.ttf", 50)
		self.game_over_character = pygame.image.load("../graphics/player/player_stand.png").convert_alpha()
		self.game_over_character = pygame.transform.rotozoom(self.game_over_character, 0, 2)
		self.game_over_character_rect = self.game_over_character.get_rect(center = (400, 150))
		self.start_game_surface = self.font.render("Press Space to start the game!", False, "Black")
		self.start_game_rect = self.start_game_surface.get_rect(center = (400, 300))

	def _get_score(self):
		self.time = pygame.time.get_ticks()
		self.score = int((self.time - self.start_time) / 1000)

		self.score_surface = self.font.render(f"Score: {self.score}", False, "Black")
		self.score_rect = self.score_surface.get_rect(center = (400, 50))

	def _remove_obstacle(self):
		for obstacle_index, obstacle in enumerate(self.obstacles):
			if obstacle.rect.right <= 0:
				self.obstacles.pop(obstacle_index)

	def _blit_active(self):
		self.display_surface.blit(self.sky_background, (0, 0))
		self.display_surface.blit(self.ground_background, (0, 300))
		self.display_surface.blit(self.score_surface, self.score_rect)
		self.display_surface.blit(self.player.image, self.player.rect)
		self._remove_obstacle()
		for obstacle in self.obstacles:		
			self.display_surface.blit(obstacle.image, obstacle.rect)
			obstacle.move()

	def _blit_game_over(self):
		self.display_surface.fill((173, 216, 230))
		self.display_surface.blit(self.game_over_character, self.game_over_character_rect)
		if self.score == 0:
			self.display_surface.blit(self.start_game_surface, self.start_game_rect)
		else:
			self.display_surface.blit(self.score_surface, (self.score_rect))

	def _game_over(self):
		if self.player.collision(self.obstacles):
			self.score_rect.y += 250
			self.game_active = False

	def _obstacle_animation(self):
		for obstacle in self.obstacles:
			obstacle.animation()

class Player():
	def __init__(self):
		self.walk1 = pygame.image.load("../graphics/player/player_walk_1.png").convert_alpha()
		self.walk2 = pygame.image.load("../graphics/player/player_walk_2.png").convert_alpha()
		self.jump_surf = pygame.image.load("../graphics/player/jump.png").convert_alpha()
		self.walk = (self.walk1, self.walk2)
		self.image = self.walk[0]
		self.rect = self.image.get_rect(bottomleft = (50, 300))
		self.gravity = 0
		self.animation_factor = 0

		# audio
		self.jump_audio = pygame.mixer.Sound("../audio/jump.mp3")
		self.jump_audio.set_volume(0.25)

	def jump(self):
		self.gravity += 1

		keys = pygame.key.get_pressed()
		if keys[pygame.K_SPACE] and self.rect.bottom == 300:
			self.gravity = -20
			self.jump_audio.play()

		self.rect.bottom += self.gravity
		if self.rect.bottom >= 300:
			self.rect.bottom = 300

	def collision(self, obstacles):
		for obstacle in obstacles:
			if self.rect.colliderect(obstacle.rect):
				return True
		return False

	def animation(self):
		self.animation_factor += 0.15
		if self.rect.bottom < 300:
			self.image = self.jump_surf
		else:
			if self.animation_factor >= len(self.walk):
				self.animation_factor = 0
			self.image = self.walk[int(self.animation_factor)]

class Snail():
	def __init__(self):
		self.crawl1 = pygame.image.load("../graphics/snail/snail1.png").convert_alpha()
		self.crawl2 = pygame.image.load("../graphics/snail/snail2.png").convert_alpha()
		self.crawl = (self.crawl1, self.crawl2)
		self.image = self.crawl[0]
		self.rect = self.image.get_rect(bottomleft = (randint(800, 900), 300))
		self.animation_factor = 0

	def move(self):
		self.rect.left -= 5

	def animation(self):
		self.animation_factor += 0.05
		if self.animation_factor >= len(self.crawl):
			self.animation_factor = 0
		self.image = self.crawl[int(self.animation_factor)]

class Fly():
	def __init__(self):
		self.fly1 = pygame.image.load("../graphics/fly/Fly1.png").convert_alpha()
		self.fly2 = pygame.image.load("../graphics/fly/Fly2.png").convert_alpha()
		self.fly = (self.fly1, self.fly2)
		self.image = self.fly[0]
		self.rect = self.image.get_rect(midbottom = (randint(950, 1150), 175))
		self.animation_factor = 0

	def move(self):
		self.rect.left -= 6

	def animation(self):
		self.animation_factor += 0.1
		if self.animation_factor >= len(self.fly):
			self.animation_factor = 0
		self.image = self.fly[int(self.animation_factor)]

if __name__ == "__main__":
	game = Game()
	game.run()